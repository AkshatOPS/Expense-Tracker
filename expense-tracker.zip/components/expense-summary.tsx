"use client"

import { Card } from "@/components/ui/card"
import type { Expense } from "@/app/page"

interface ExpenseSummaryProps {
  expenses: Expense[]
}

export function ExpenseSummary({ expenses }: ExpenseSummaryProps) {
  const totalAmount = expenses.reduce((sum, expense) => sum + expense.amount, 0)

  const currentMonth = new Date().toISOString().slice(0, 7) // YYYY-MM format
  const monthlyExpenses = expenses.filter((expense) => expense.date.startsWith(currentMonth))
  const monthlyTotal = monthlyExpenses.reduce((sum, expense) => sum + expense.amount, 0)

  const categoryTotals = expenses.reduce(
    (acc, expense) => {
      acc[expense.category] = (acc[expense.category] || 0) + expense.amount
      return acc
    },
    {} as Record<string, number>,
  )

  const topCategory = Object.entries(categoryTotals).sort(([, a], [, b]) => b - a)[0]

  return (
    <div className="grid gap-4 md:grid-cols-3">
      <Card className="p-6 text-center">
        <h3 className="text-sm font-medium text-muted-foreground mb-2">Total Spent</h3>
        <p className="text-3xl font-light text-foreground">${totalAmount.toFixed(2)}</p>
      </Card>

      <Card className="p-6 text-center">
        <h3 className="text-sm font-medium text-muted-foreground mb-2">This Month</h3>
        <p className="text-3xl font-light text-foreground">${monthlyTotal.toFixed(2)}</p>
      </Card>

      <Card className="p-6 text-center">
        <h3 className="text-sm font-medium text-muted-foreground mb-2">Top Category</h3>
        <p className="text-lg font-medium text-foreground">{topCategory ? topCategory[0] : "None"}</p>
        {topCategory && <p className="text-sm text-muted-foreground">${topCategory[1].toFixed(2)}</p>}
      </Card>
    </div>
  )
}
